﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;

namespace CodeChum
{
    public partial class LoginForm : Form
    {
       
        private Dictionary<string, string> userCredentials = new Dictionary<string, string>
        {
            {"admin", "admin12345" },
            {"user1", "password123" },
            {"student1", "PF101@2024" }
        };

        public LoginForm()
        {
            InitializeComponent();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            string username = usernameTextBox.Text;
            string password = passwordTextBox.Text;

           
            if (userCredentials.ContainsKey(username) && userCredentials[username] == password)
            {
                resultLabel.Text = "Login Successful";
            }
            else
            {
                resultLabel.Text = "Invalid username or password.";
            }
        }

        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

    
    }
}
